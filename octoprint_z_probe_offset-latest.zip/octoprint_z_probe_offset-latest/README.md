# Octoprint_Z_probe_offset

Octoprint plugin adding Z probe offset setting on 3d printers using Marlin firmware