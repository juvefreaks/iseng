# Changelog
## [0.4] - 2020-07-28
 - Fix bug: Can't set offset to 0 (c41e1748)

## [0.3] - 2020-06-23
 - Fix bug: Error message when no z probe found doesn't always show up (5bc0f06e)
 - Fix bug: Save to eeprom (M500) sometimes triggered before M851Z[Value] (75cbe940)
 - Add Creality3D firmware variant support (b7f8af78, 226c8353, 9459af3b)
 - Add Prusa firmware variant support (03716b71, 03716b71, 03716b71)

## [0.2] - 2020-06-14
 - Add plugin repo definition markdown file
 - Add screenshot

## [0.1] - 2020-06-14
 - Initial release