from __future__ import absolute_import

import json
import threading
import flask
import requests
from requests.exceptions import ConnectionError as ConnErr, ConnectTimeout
import octoprint.plugin  # pylint: disable=import-error
from octoprint.events import Events  # pylint: disable=import-error

GIT_PROJECT_ID = '63729'
GIT_NAME = 'Octoprint_Z_probe_offset'
GIT_USER = 'razer'

GIT_URL = 'https://framagit.org'
GIT_RELEASES = GIT_URL + '/api/v4/projects/' + GIT_PROJECT_ID + '/releases'
GIT_ARCHIVES = GIT_URL + '/' + GIT_USER + '/' + GIT_NAME + '/-/archive'

class _VersionCheck:
    @classmethod
    def get_remote_version(cls):
        try:
            req = requests.get(GIT_RELEASES, timeout=5)
        except (ConnErr, ConnectTimeout):
            return None
        response = req.json()
        if not response or not isinstance(response, list):
            return None
        tag_map = map(lambda r: r['tag_name'], response)
        release_map = filter(lambda v: v.replace('.', '').isdigit(), tag_map)
        release_map = list(map(float, release_map))
        release_map.sort(reverse=True)
        if not release_map:
            return None
        return str(release_map[0])

    @classmethod
    def get_latest(cls, target, check, full_data=False, online=True):
        # pylint: disable=unused-argument
        current_version = check.get('current', '1.0.0')
        remote_version = current_version
        if online:
            remote_version = cls.get_remote_version() or current_version
        info = dict(local=dict(name=current_version, value=current_version),
                    remote=dict(name=remote_version, value=remote_version))
        return info, remote_version == current_version


# pylint: disable=attribute-defined-outside-init
class Z_probe_offset_plugin(octoprint.plugin.AssetPlugin,
                            octoprint.plugin.EventHandlerPlugin,
                            octoprint.plugin.SimpleApiPlugin,
                            octoprint.plugin.TemplatePlugin):

    def initialize(self):
        self._version = '0.4'
        self._plugin_version = self._version
        self.z_offset = None
        self.printer_cap = {'eeprom': None, 'z_probe': None}
        self.prusa_firmware = False
        self.prusa_zoffset_following = False

    def get_update_information(self):
        return dict(Z_probe_offset=dict(
            displayName='Z Probe Offset Control',
            displayVersion=self._plugin_version,
            current=self._plugin_version,
            type='python_checker',
            python_checker=_VersionCheck,
            pip=GIT_ARCHIVES + '/{target}/%s-{target}.zip' % GIT_NAME))

    def get_template_configs(self):
        return [dict(type='generic', template='%s.jinja2' % self._identifier)]

    def get_assets(self):
        return dict(js=['%s.js' % self._identifier])

    def on_api_get(self, unused_request):
        return flask.jsonify(printer_cap=self.printer_cap,
                             z_offset=self.z_offset)

    def on_event(self, event, payload):
        if event == 'Disconnected':
            self.printer_cap = {'eeprom': None, 'z_probe': None}
            self._send_message('printer_cap', json.dumps(self.printer_cap))
        elif event == 'Connected':
            self._printer.commands(['M851'])
        elif event == Events.FIRMWARE_DATA:
            self._logger.debug('Get firmware data: %s - %s',
                               payload.get('name'), payload.get('data'))
            self.prusa_firmware = 'prusa' in payload.get('name').lower()

    def set_z_offset_from_printer_response(self, offset):
        offset = offset.replace(' ', '').replace('"', '')
        if not offset:
            self._logger.warning('Offset part is empty !')
            return
        if not offset.replace('-', '', 1).replace('.', '', 1).isdigit():
            self._logger.warning('Unable to extract Z offset from "%s"', offset)
            return
        self._logger.info('Z probe offset is now %s', offset)
        if not self.printer_cap['z_probe']:
            self._logger.warning('Set printer\'s z probe cap as enabled, M115 '
                                 + 'firmware response supposed buggy')
            self.printer_cap['z_probe'] = 1
            self._send_message('printer_cap', json.dumps(self.printer_cap))
        self.z_offset = float(offset)
        self._send_message('z_offset', self.z_offset)

    def set_z_offset_from_gcode(self, line):
        offset_map = line.lower().replace('m851', '').split()
        z_part = list(filter(lambda v: v.startswith('z'), offset_map))
        if not z_part:
            self._logger.warning('Bad M851 response: %s', line)
            return
        self.set_z_offset_from_printer_response(z_part[0][1:])

    def on_printer_gcode_sent(self, comm, phase, cmd, cmd_type, gcode, *args,
                              **kwargs):
        # pylint: disable=too-many-arguments, unused-argument
        if gcode and 'm851' in gcode.lower() and cmd.replace(gcode, ''):
            self._logger.debug('Setting z offset from user command %s', cmd)
            self.set_z_offset_from_gcode(cmd.replace(gcode, ''))

    def populate_printer_cap(self, line):
        cap = list(filter(lambda c: c in line.lower(), self.printer_cap))
        if not cap:
            return None
        cap = cap[0]
        self.printer_cap[cap] = int(line.split(':')[-1])
        self._logger.info('Printer_cap[%s]:%s', cap, line.split(':')[-1])
        return True

    def on_printer_gcode_received(self, comm, line, *args, **kwargs):
        # pylint: disable=unused-argument
        if self.prusa_zoffset_following:
            self.prusa_zoffset_following = False
            self._logger.debug('Z offset value (prusa): %s', line)
            self.set_z_offset_from_printer_response(line)
            return line
        if len(line) < 3:
            return line
        line_lower = line.lower().strip()
        if 'cap:' in line_lower:
            cap_populated = self.populate_printer_cap(line)
            if cap_populated:
                self._send_message('printer_cap', json.dumps(self.printer_cap))
        elif 'zprobe_zoffset' in line_lower:
            self._logger.debug('CR3D M851 echo: %s', line)
            self.set_z_offset_from_printer_response(line.split('=')[-1])
        elif 'probe z offset:' in line_lower:
            self._logger.debug('Marlin 1.x M851 echo: %s', line)
            self.set_z_offset_from_printer_response(line.split(':')[-1])
        elif line_lower.endswith('z offset') and self.prusa_firmware:
            self._logger.debug('Prusa M851 echo: z offset may follow')
            self.prusa_zoffset_following = True
        elif 'z offset' in line_lower:
            self._logger.debug('CR3D variant echo to M851Z[VALUE]: %s', line)
            self.set_z_offset_from_printer_response(line.split(' ')[-1])
        elif 'm851' in line_lower or 'probe offset ' in line_lower:
            self._logger.debug('Marlin 2.x M851 echo: %s', line)
            self.set_z_offset_from_gcode(line.replace('probe offset', ''))
        elif '?z out of range' in line_lower:
            self._logger.error('Setting z offset: %s', line)
            self._send_message('offset_error', line.replace('?', ''))
            self._printer.commands(['M851'])
        return line

    def _send_message(self, msg_type, message):
        self._plugin_manager.send_plugin_message(
            self._identifier,
            dict(type=msg_type, msg=message))

__plugin_name__ = 'Z Probe Offset'
__plugin_pythoncompat__ = ">=2.7,<4"

def __plugin_load__():
    # pylint: disable=global-variable-undefined
    global __plugin_implementation__
    __plugin_implementation__ = Z_probe_offset_plugin()

    global __plugin_hooks__
    __plugin_hooks__ = {
        'octoprint.plugin.softwareupdate.check_config':
        __plugin_implementation__.get_update_information,
        'octoprint.comm.protocol.gcode.received':
        __plugin_implementation__.on_printer_gcode_received,
        'octoprint.comm.protocol.gcode.sent':
        __plugin_implementation__.on_printer_gcode_sent,
    }
